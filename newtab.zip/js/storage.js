if(chrome && chrome.storage && chrome.storage.sync) {
	//chrome.storage.sync.set({name: value});

  /*
  chrome.storage.sync.get(name, function(data) {
    return (data);
  });
  */

}